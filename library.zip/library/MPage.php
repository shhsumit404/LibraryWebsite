<!DOCTYPE html>
<html>
<head>
	<title>Welcome Back</title>
	<style >
		body {
			background-color: #2c3e50;
		}
		div {
			width: 1000px;
			height: 100px;
			background-color: cyan;
		}
		.invalid {
			color: red;
			text-align: center;
		}
		a {
			text-decoration: none;
		}
		button.fail {
			background-color: #e74c3c;
			color: white;
			margin-left: 450px;
		}
		h1 {
			color: white;
			text-align: center;
		}
		.success {
			width: 1000px;
			height: 300px;
			background-color: #2980b9;
			margin: auto;
			opacity: 0.8;
		}
		.head {
			background-color: #e67e22;
			text-align: center;
			font-weight: 40px;
			color: white;
		}
		h4 {
			text-align: center;
			color: white;
		}
		.add {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #d35400;
			color: white;
			margin-left: 120px;
		}
		.add1 {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #d35400;
			color: white;
			margin-left: 450px;
		}
		.add2 {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #d35400;
			color: white;
			margin-left: 450px;
		}
		.add:hover {
			background-color: #9b59b6;
		}
		.add1:hover {
			background-color: #9b59b6;
		}
		.add2:hover {
			background-color: red;
		}
	</style>
</head>
<body>
	<h3 class="head">MyLib</h3>
<?php

	$message = "";
	if (count($_POST) > 0)
	{
		$conn = mysqli_connect("localhost", "root", "", "books");
		$result = mysqli_query($conn,"SELECT * FROM user_info WHERE username='" . $_POST["username"] . "' and password = '". $_POST["password"]."'");
	$count  = mysqli_num_rows($result);
	if($count==0) {
		//$message = "Invalid Username or Password!";
		//echo $message;
		?>

	<br><br>
	<div>
	<h1 class="invalid">Invalid Username or Password</h1>
	<a href="slogin.php">
		<button class="fail">
			Go Back!
		</button>
	</a>
    </div>
	<?php
	} 
	else {
	?>
	<br><br>
	<div class="success">
	<h1>Welcome Back</h1>
	<h4>What you want to do?</h4>

	<a href="EnterBooks.php">
		<button class="add">Add new books</button>
	</a>
	<a href="DisplayBooks.php">
		<button class="add">Display Collection</button>
	</a>
	<a href="UDisplayBooks.php">
		<button class="add">Update Collection</button>
	</a>
	<a href="StaffRent.php">
		<button class="add">Show Rentals</button>
	</a><br><br>
	<a href="">
		<button class="add1">
			Update profile
		</button>
	</a><br><br>
	<a href="slogin.php">
		<button class="add2">Sign out</button>
	</a>
	</div>

	<?php
	}
	}
	?>

</body>
</html>