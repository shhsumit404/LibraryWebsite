<!DOCTYPE html>
<html>
<head>
	<title>Rent Details</title>
</head>
<body>

<?php
include("DBConnection.php");
 
//$search = $_REQUEST["search"];
 
$query = "select Name,NDay, ISBN from rent"; 
$result = mysqli_query($db,$query);
 
if(mysqli_num_rows($result)>0)if(mysqli_num_rows($result)>0)
 
{
?>
<br><br>
<table border="2" align="center" cellpadding="5" cellspacing="5">
 
<tr>
<th> Name </th>
<th> No of Days to Rent </th>
<th> ISBN </th>
<th> Action </th>
</tr>
 
<?php while($row = mysqli_fetch_assoc($result))
{
?>
<tr>
<td><?php echo $row["Name"];?> </td>
<td><?php echo $row["NDay"];?> </td>
<td><?php echo $row["ISBN"];?> </td>
<td>
	<form action="Approve.php">
		<input type="submit" name="approve" value="Approve">
	</form>
	<form >
	<input type="submit" name="decline" value="Decline">
</form>
</td>
</tr>
<?php
}
}
else
echo "<center>No books found in the library by the name</center>" ;
?>
</table><br><br>
<a href="slogin.php">
	<button>Sign Out</button>
</a>

</body>
</html>