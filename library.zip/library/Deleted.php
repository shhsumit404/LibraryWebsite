<!DOCTYPE html>
<html>
<head>
	<title>Successful</title>
	<style >
		body
		{
			background-color: #34495e;
			color: white;
		}
	</style>
</head>
<body>

	<script >
		alert("The book is no longer in your database");
	</script>

	<h1>The Book is deleted</h1>
	<br>
	<br>
	<a href="DisplayBooks.php">
		<button>
			To display the current books click here
		</button>
	</a>
	<br><br>
	<a href="slogin.php">
		<button>
			Sign Out
		</button>
	</a>

	<?php

	include ("DBConnection.php");

	$ISBN = $_GET["ISBN"];

	$query = "delete from book_info where ISBN = '$ISBN';";

	$result = mysqli_query($db, $query);

	?>

</body>
</html>