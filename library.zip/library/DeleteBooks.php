<!DOCTYPE html>
<html>
<head>
	<title>Delete Book</title>
	<style >
		body {
			background-color: #34495e;
			color: white;
		}
	</style>
</head>
<body>

	<form action="Deleted.php" method="GET">
		Please Enter the ISBN <br>
		<input type="text" name="ISBN">
		<br><br><br>
		<input type="submit" name="delete" value="Delete">
	</form><br><br>
	<a href="UDisplayBooks.php">
		<button>
			Cancel
		</button>
	</a>

</body>
</html>