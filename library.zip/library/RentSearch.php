<!DOCTYPE html>
<html>
<head>
	<title>Search Books</title>
	<style>
		body {
			background: url(img/hero-slider/L1.jpg) center no-repeat;
			background-size: cover;
		}
		h1 {
			text-align: center;
			color: white;
			background-color: #d35400;
			opacity: 0.8;
		}
		h2 {
			text-align: center;
			font-weight: 20px;
			color: white;
		}
		div {
			background-color: #2c3e50;
			width: 500px;
			height: 400px;
			margin: auto;
			opacity: 0.8;
		}
		.button {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #d35400;
			color: white;
		}
		.button:hover {
			opacity: 1;
			background-color: #16a085;
			color: white;
		}
		.in {
			height: 30px;
			border: 0px solid;
			border-radius: 10px;
		}
		button {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #9b59b6;
			color: white;
			margin-left: 200px;
		}
		button:hover {
			background-color: red;
		}
	</style>
</head>
<body>

<center><h1>MyLib</h1></center>
<div>
<form action = "RDisplay.php" method="get">
<br>
<center>
<h2>Enter the title of the book<h2>
<input type="text" name="search" size="48" class="in">
<br></br>
<input type="submit" value="Submit" class="button">
<input type="reset" value="Reset" class="button">
<br><br><br><br><br><br>
</center>
<br>
</form>
<a href="index.php">
	<button>Sign Out</button>
</a>
</div>

</body>
</html>