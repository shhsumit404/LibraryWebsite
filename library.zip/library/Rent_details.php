
<!DOCTYPE html>
<html>
<head>
	<title>Rent Details</title>
	<style>
		body {
			background-color: #2c3e50;
			color: white;
		}
		div {
			margin: auto;
		}
		a {
			text-decoration: none;
			color: white;
			font-style: italic;
		}
	</style>
</head>
<body>

	<div>
		<form action="Rented.php" method="POST">
			<table>
			<tr>
				<th></th>
				<th></th>
			</tr>
			<tr>
			<td>Name</td>
			<td><input type="text" name="name" required></td>
		    </tr>
		    <tr>
			<td>ISBN</td>
			<td><input type="text" name="isbn" required></td>
		    </tr>
		    <tr>
		    <td>No of days you want to rent</td>
		   	<td><input type="text" name="nod" required></td>
		    </tr>
		</table>
		<input type="checkbox" name="click" required>By clicking the box you're agreeing <a href="#"><u>terms and conditions</u></a> of myLib  <br><br>
		<input type="submit" name="submit" value="Rent">
		</form><br><br>
		<a href="RentSearch.php">
			<button>
				Cancel
			</button>
		</a>
	</div>

</body>
</html>