<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>About</title>
	<meta charset="UTF-8">
	<meta name="description" content="loans HTML Template">
	<meta name="keywords" content="loans, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap" rel="stylesheet">
 
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->

</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header Section -->
	<header class="header-section">
		<a href="index.php" class="site-logo">
			<h4 style="color: grey;">myLib</h4>
		</a>
		<nav class="header-nav">
			<ul class="main-menu">
				<li><a href="index.php">Home</a></li>
				<li><a href="about-us.php" class="active">About</a></li>
				<li><a href="slogin.php">Staff</a>
				</li>
				<li><a href="contact.php" target="_blank">Contact</a></li>
			</ul>
			<div class="header-right">
				<a href="#" class="hr-btn"><i class="flaticon-029-telephone-1"></i>Call us now! </a>
				<div class="hr-btn hr-btn-2" style="background-color: navy;">+X XXX XXX XXXX</div>
			</div>
		</nav>
	</header>
	<!-- Header Section end -->

	<!-- Page top Section end -->
	<section class="page-top-section set-bg" data-setbg="img/L4.jpg">
		<div class="container">
			<h2 style="color: black;">About Me</h2>
			<nav class="site-breadcrumb">
				<a class="sb-item" href="index.php" style="color: black;">Home</a>
				<span class="sb-item active" style="color:black;">About me</span>
			</nav>
		</div>
	</section>
	<!-- Page top Section end -->

	<!-- About Section end -->
	<section class="about-section spad">
		<div class="container">
			<div class="row">
				<div class="col-lg-5">
					<img style="width:500px; height: 300px;" src="img/Sumit.jpg" alt="">
				</div>

				<div class="col-lg-7">

					<div class="about-text">
						<h2>Biography</h2>
						<p>Hi, I am Sumit Barua, a sophomore student majoring in Computer Science at Western Michigan University. I am a person having strong passion to learn something new and do something different. </p>
						<a href="#" class="site-btn">Find out more</a>
					</div>

					<div class="about-text">
						<h2>About This Project</h2>
						<p>The project named Library Management System is a Library Management software to monitor and control the entire transaction in a library. This system is gaining more importance, as the number of its users is increasing rapidly. The project is tend to be designed using HTML, CSS, Javascript and MySQL. The transaction like login, register, add, search, delete, issue are provided. The system stores the details like name, address, ID no., Date of birth of employees and the users who registered for the system. The details of books like book name, book no., subject, author, edition, year of publication, the total number of books that are available in the library.</p>
						<a href="#" class="site-btn">Find out more</a>
					</div>
				</div>
			</div>
		</div>
	</section>
	<!-- About Section end -->

	<!-- Review Section end -->
	
	<!-- Footer Section end -->
	
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/main.js"></script>

	</body>
</html>
