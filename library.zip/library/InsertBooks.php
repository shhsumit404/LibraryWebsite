<!DOCTYPE HTML>
<html>
<head>
	<title>Insertion</title>
	<style >
		body
		{
			background: url(img/BookInsert.jpg) no-repeat;
			background-size: cover;
		}
		h1.head {
			text-align: center;
			color: white;
			background-color: #d35400;
			opacity: 0.8;
		}
		h3 {
			color: white;
			text-align: center;
		}
		div {
			width: 500px;
			height: 400px;
			background-color: #16a085;
			margin: auto;
			opacity: 0.8;
		}
		div h1{
			text-align: center;
			color: white;
			font-weight: 50px;
		}
		a.search {
			text-decoration: none;
			text-align: center;
			margin-left: 100px;
			color: white;
		}
		a.insert {
			text-decoration: none;
			margin-left: 180px;
			color: white;
		}

	</style>
</head>
<body>
<center><h1 class="head"><a href="index.php" style="text-decoration: none;color: white;">MyLib</a></h1></center>
<br>
 
<?php
include("DBConnection.php");
 
$isbn=$_POST["isbn"];
$title=$_POST["title"];
$author=$_POST["author"];
$edition=$_POST["edition"];
$publication=$_POST["publication"];
 
$query = "insert into book_info(isbn,title,author,edition,publication) values('$isbn','$title','$author','$edition','$publication')"; //Insert query to add book details into the book_info table
$result = mysqli_query($db,$query);
 
?>
<div>
	<br><br>
	<h1>SUCCESSFUL!</h1>
<h3> Book information is inserted successfully </h3><br><br><br>
<a href="EnterBooks.php" class="insert"><button>Insert Another Book</button></a>
 <br><br>
<a href="SearchBooks.php" class="search" target="_blank">
<button>To search for the Book information click here</button></a><br><br><br>
<a href="slogin.php"><button style="width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #9b59b6;
			color: white;
			margin-left: 200px;">Sign Out</button></a>
</div>
 
</body>
</html>