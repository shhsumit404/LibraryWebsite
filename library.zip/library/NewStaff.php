// The new staff sign up
// It will be directed to WelcomeNew.php file