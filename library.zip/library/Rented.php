<!DOCTYPE html>
<html>
<head>
	<title>Successful!</title>
</head>
<body>

	<script >
		alert("Your rent request is succesful");
	</script>

	<h2>Please visit the customer service desk with valid ID to claim your rented book</h2>
	<a href="index.php">
		<button>Go back to your homepage</button>
	</a>

	<?php

	include("DBConnection.php");
	$name = $_POST['name'];
	$isbn = $_POST['isbn'];
	$nod = $_POST['nod'];

	$query = "Insert into Rent(Name, NDay, ISBN)
	          VALUES('$name','$nod', '$isbn')";
	$result = mysqli_query($db, $query);

	?>

</body>
</html>