<!DOCTYPE html>
<html>
<head>
	<title>Successful</title>
</head>
<body>

	<script>
		alert(Rent has been approved!);
	</script>

	<h3>Rent has been approved!</h3>

	<a href="slogin.php">
		<button>
			Sign Out
		</button>
	</a>

	<?php

	include("DBConnection.php");
	$query = "Delete from rent";
	$result = mysqli_query($db, $query);

	?>

</body>
</html>