<!DOCTYPE html>
<html lang="zxx">
<head>
	<title>Sumit's Library Management System</title>
	<meta charset="UTF-8">
	<meta name="description" content="loans HTML Template">
	<meta name="keywords" content="loans, html">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
	<!-- Favicon -->
	<link href="img/favicon.ico" rel="shortcut icon"/>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&display=swap" rel="stylesheet">
 
	<!-- Stylesheets -->
	<link rel="stylesheet" href="css/bootstrap.min.css"/>
	<link rel="stylesheet" href="css/font-awesome.min.css"/>
	<link rel="stylesheet" href="css/owl.carousel.min.css"/>
	<link rel="stylesheet" href="css/flaticon.css"/>
	<link rel="stylesheet" href="css/slicknav.min.css"/>

	<!-- Main Stylesheets -->
	<link rel="stylesheet" href="css/style.css"/>


	<!--[if lt IE 9]>
		<script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
		<script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
  
    </style>
</head>
<body>
	<!-- Page Preloder -->
	<div id="preloder">
		<div class="loader"></div>
	</div>

	<!-- Header Section -->
	<header class="header-section">
		<a href="index.php" class="site-logo">
			<h4 style="color: grey;">myLib</h4>
		</a>
		<nav class="header-nav">
			<ul class="main-menu">
				<li><a href="index.php" class="active">Home</a></li>
				<li><a href="about-us.php">About</a></li>
				<li><a href="slogin.php">Staff</a>
				</li>
				<li><a href="contact.php" >Contact</a></li>
			</ul>
			<div class="header-right">
				<a href="#" class="hr-btn"><i class="flaticon-029-telephone-1"></i>Call us now! </a>
				<div class="hr-btn hr-btn-2" style="background-color: navy;">+X XXX XXX XXXX</div>
			</div>
		</nav>
	</header>
	<!-- Header Section end -->

	<!-- Hero Section end -->
	<section class="hero-section">
		<div class="container">
			<div class="row">
				<div class="col-lg-6">
					<div class="hs-text">
						<h2>Welcome To My Library</h2>
						<p>Welcome to my Database Management System Project called Library Management System</p>
						
					</div>
				</div>
				<div class="col-lg-6">
					<form class="hero-form" action="SPage.php" method="POST">
						
						<h2 style="color: #bdc3c7;">Member Login</h2><br>
						<input type="email" placeholder="Your E-mail" required>
						<input type="text" placeholder="myLibID" name="username" required>
						<input type="password" placeholder="Password" name="password" required>
						<p>By clicking the Sign In button below, you are agreeing the terms and conditions of MyLib</p>
						<button class="site-btn" style="background-color: navy;">Sign In</button><br><br>
						<a href="SUpdate.php" style="color: white;" target="_blank">New Member?</a>
					</form>
				</div>
			</div>
		</div>
		<div class="hero-slider owl-carousel">
			<div class="hs-item set-bg" data-setbg="img/hero-slider/L1.jpg"></div>
			<div class="hs-item set-bg" data-setbg="img/L2.jpg"></div>
			<div class="hs-item set-bg" data-setbg="img/L3.jpg"></div>
		</div>
	</section>
	<!-- Hero Section end -->

	
	
	<!-- Footer Section end -->
	
	<!--====== Javascripts & Jquery ======-->
	<script src="js/jquery-3.2.1.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.slicknav.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery-ui.min.js"></script>
	<script src="js/main.js"></script>
<?php
include("DBConnection.php");
 
$user=$_POST["username"];
$pass=$_POST["password"];

$query = "insert into student(username,password) values('$user', '$pass')"; //Insert query to add book details into the book_info table
$result = mysqli_query($db,$query);
 
?>

</body>

</html>
