<!DOCTYPE html>
<html>
<head>
	<title>Update</title>
	<style >
		h2.head {
			color: white;
			background-color: #e67e22;
			text-align: center;
		}
		button {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #9b59b6;
			color: white;
			margin-left: 450px;
		}
		button:hover {
			background-color: red;
		}
	</style>
</head>
<body>
<center><h2 class="head">MyLib</h2></center>
<br>
 
<?php
include("DBConnection.php");
 
//$search = $_REQUEST["search"];
 
$query = "select ISBN,Title,Author,Edition,Publication from book_info"; //search with a book name in the table book_info
$result = mysqli_query($db,$query);
 
if(mysqli_num_rows($result)>0)if(mysqli_num_rows($result)>0)
 
{
?>
 
<table border="2" align="center" cellpadding="5" cellspacing="5">
 
<tr>
<th> ISBN </th>
<th> Title </th>
<th> Author </th>
<th> Edition </th>
<th> Publication </th>
<th> Action </th>
</tr>
 
<?php while($row = mysqli_fetch_assoc($result))
{
?>
<tr>
<td><?php echo $row["ISBN"];?> </td>
<td><?php echo $row["Title"];?> </td>
<td><?php echo $row["Author"];?> </td>
<td><?php echo $row["Edition"];?> </td>
<td><?php echo $row["Publication"];?> </td>
<td><form action="DeleteBooks.php">
	<input type = "submit" name="del" value="Delete">
</form>
</td>
</tr>
<?php
}
}
else
echo "<center>No books found in the library by the name $search </center>" ;
?>
</table><br><br>
<a href="slogin.php">
	<button>
		Sign Out
	</button>
</a>
</body>
</html>