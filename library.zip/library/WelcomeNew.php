// This will welcome the new staff member 
// This will insert new information in user_info table
// It will ask to go back to staff login and login with using their own credentials