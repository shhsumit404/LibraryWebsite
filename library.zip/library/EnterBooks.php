<!DOCTYPE HTML>
<html>
<head>
	<title>Book Info</title>
	<style >
		body{
			background: url(img/EnterBook.gif) no-repeat;
			background-size: cover;
		}
		h1 {
			text-align: center;
			color: white;
			background-color: #d35400;
			opacity: 0.8;
		}
		table {
			background-color: #2c3e50;
			opacity: 0.8;
			width: 600px;
			height: 350px;
		}
		td {
			color: white;
			text-align: center;
		}
		.button1 {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #d35400;
			color: white;
			margin-left: 400px;
			opacity: 0.8;
		}
		.button {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #d35400;
			color: white;
			opacity: 0.8;
		}
		.button:hover {
			opacity: 1;
			background-color: #16a085;
			color: white;
			opacity: 1;
		}
		.button1:hover {
			opacity: 1;
			background-color: #16a085;
			color: white;
			opacity: 1;
		}
		button {
			width: 100px;
			height: 40px;
			border: 0px solid;
			border-radius: 10px;
			background-color: #9b59b6;
			color: white;
			margin-left: 450px;
		}
		button:hover {
			background-color: red;
		}
	</style>
</head>
<body>
<center><h1><a href="index.php" style="text-decoration: none;color: white;">MyLib</a></h1></center><br>
<!--Once the form is submitted, all the form data is forwarded to InsertBooks.php -->
<form action="InsertBooks.php" method="post">
 
<table border="0" align="center" cellpadding="5" cellspacing="5">
<tr>
<td> ISBN </td>
<td> <input type="text" name="isbn" size="48" required="ISBN is required"> </td>
</tr>
<tr>
<td> Title </td>
<td> <input type="text" name="title" size="48" required="Title is required"> </td>
</tr>
<tr>
<td> Author </td>
<td> <input type="text" name="author" size="48" required="Author name is required"> </td>
</tr>
<tr>
<td> Edition </td>
<td> <input type="text" name="edition" size="48" required="Edition is required"> </td>
</tr>
<tr>
<td> Publication </td>
<td> <input type="text" name="publication" size="48"> </td>
</tr>
</table>
<br>
<input type="submit" value="Submit" class="button1">
<input type="reset" value="Reset" class="button">
<br><br>
</form>
<a href="index.php">
<button>Sign out</button>
</a>
</body>
</html>